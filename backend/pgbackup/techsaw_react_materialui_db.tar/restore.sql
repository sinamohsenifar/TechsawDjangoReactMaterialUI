--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 14.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE techsaw_react_materialui_db_2;
--
-- Name: techsaw_react_materialui_db_2; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE techsaw_react_materialui_db_2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Persian_Iran.1256';


ALTER DATABASE techsaw_react_materialui_db_2 OWNER TO postgres;

\connect techsaw_react_materialui_db_2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: blog_article; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_article (
    id uuid NOT NULL,
    slug character varying(50),
    image character varying(100) NOT NULL,
    title character varying(200),
    main_description text,
    num_comments integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    category_id bigint,
    author_id uuid,
    video character varying(100),
    num_likes integer NOT NULL,
    source_link character varying(255),
    source_name character varying(255),
    views integer NOT NULL,
    CONSTRAINT blog_article_num_likes_88dc7017_check CHECK ((num_likes >= 0)),
    CONSTRAINT blog_article_views_check CHECK ((views >= 0))
);


ALTER TABLE public.blog_article OWNER TO postgres;

--
-- Name: blog_article_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_article_tags (
    id bigint NOT NULL,
    article_id uuid NOT NULL,
    articletag_id bigint NOT NULL
);


ALTER TABLE public.blog_article_tags OWNER TO postgres;

--
-- Name: blog_article_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_article_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_article_tags_id_seq OWNER TO postgres;

--
-- Name: blog_article_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_article_tags_id_seq OWNED BY public.blog_article_tags.id;


--
-- Name: blog_articlefavorite; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_articlefavorite (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    article_id uuid NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.blog_articlefavorite OWNER TO postgres;

--
-- Name: blog_articlefavorite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_articlefavorite_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_articlefavorite_id_seq OWNER TO postgres;

--
-- Name: blog_articlefavorite_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_articlefavorite_id_seq OWNED BY public.blog_articlefavorite.id;


--
-- Name: blog_articlelike; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_articlelike (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    article_id uuid NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.blog_articlelike OWNER TO postgres;

--
-- Name: blog_articlelike_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_articlelike_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_articlelike_id_seq OWNER TO postgres;

--
-- Name: blog_articlelike_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_articlelike_id_seq OWNED BY public.blog_articlelike.id;


--
-- Name: blog_articletag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_articletag (
    id bigint NOT NULL,
    name character varying(35) NOT NULL,
    slug character varying(250) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.blog_articletag OWNER TO postgres;

--
-- Name: blog_articletag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_articletag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_articletag_id_seq OWNER TO postgres;

--
-- Name: blog_articletag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_articletag_id_seq OWNED BY public.blog_articletag.id;


--
-- Name: blog_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_category (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(50) NOT NULL
);


ALTER TABLE public.blog_category OWNER TO postgres;

--
-- Name: blog_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_category_id_seq OWNER TO postgres;

--
-- Name: blog_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_category_id_seq OWNED BY public.blog_category.id;


--
-- Name: blog_comment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_comment (
    id uuid NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    rating numeric(2,1) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    article_id uuid,
    user_id uuid,
    verified boolean NOT NULL
);


ALTER TABLE public.blog_comment OWNER TO postgres;

--
-- Name: blog_extradescription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_extradescription (
    id bigint NOT NULL,
    image character varying(100),
    video character varying(100),
    main_description text,
    article_id uuid NOT NULL,
    title character varying(255)
);


ALTER TABLE public.blog_extradescription OWNER TO postgres;

--
-- Name: blog_extradescription_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_extradescription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_extradescription_id_seq OWNER TO postgres;

--
-- Name: blog_extradescription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_extradescription_id_seq OWNED BY public.blog_extradescription.id;


--
-- Name: blog_subcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_subcategory (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(50) NOT NULL,
    parent_id bigint NOT NULL
);


ALTER TABLE public.blog_subcategory OWNER TO postgres;

--
-- Name: blog_subcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blog_subcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_subcategory_id_seq OWNER TO postgres;

--
-- Name: blog_subcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blog_subcategory_id_seq OWNED BY public.blog_subcategory.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id uuid NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: rest_users_customuser; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rest_users_customuser (
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    id uuid NOT NULL,
    image character varying(100) NOT NULL,
    username character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    is_verify boolean NOT NULL
);


ALTER TABLE public.rest_users_customuser OWNER TO postgres;

--
-- Name: rest_users_customuser_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rest_users_customuser_groups (
    id bigint NOT NULL,
    customuser_id uuid NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.rest_users_customuser_groups OWNER TO postgres;

--
-- Name: rest_users_customuser_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rest_users_customuser_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rest_users_customuser_groups_id_seq OWNER TO postgres;

--
-- Name: rest_users_customuser_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rest_users_customuser_groups_id_seq OWNED BY public.rest_users_customuser_groups.id;


--
-- Name: rest_users_customuser_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rest_users_customuser_user_permissions (
    id bigint NOT NULL,
    customuser_id uuid NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.rest_users_customuser_user_permissions OWNER TO postgres;

--
-- Name: rest_users_customuser_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rest_users_customuser_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rest_users_customuser_user_permissions_id_seq OWNER TO postgres;

--
-- Name: rest_users_customuser_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rest_users_customuser_user_permissions_id_seq OWNED BY public.rest_users_customuser_user_permissions.id;


--
-- Name: store_book; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_book (
    id uuid NOT NULL,
    slug character varying(50) NOT NULL,
    image character varying(100) NOT NULL,
    title character varying(200),
    publisher character varying(200),
    description text,
    rating numeric(7,2),
    "numReviews" integer,
    price numeric(7,2),
    "countInStock" integer,
    "createdAt" timestamp with time zone NOT NULL,
    category_id bigint NOT NULL,
    user_id uuid
);


ALTER TABLE public.store_book OWNER TO postgres;

--
-- Name: store_book_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_book_tags (
    id bigint NOT NULL,
    book_id uuid NOT NULL,
    booktag_id bigint NOT NULL
);


ALTER TABLE public.store_book_tags OWNER TO postgres;

--
-- Name: store_book_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_book_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_book_tags_id_seq OWNER TO postgres;

--
-- Name: store_book_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_book_tags_id_seq OWNED BY public.store_book_tags.id;


--
-- Name: store_booktag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_booktag (
    id bigint NOT NULL,
    name character varying(35) NOT NULL,
    slug character varying(250) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.store_booktag OWNER TO postgres;

--
-- Name: store_booktag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_booktag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_booktag_id_seq OWNER TO postgres;

--
-- Name: store_booktag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_booktag_id_seq OWNED BY public.store_booktag.id;


--
-- Name: store_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_category (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(50) NOT NULL
);


ALTER TABLE public.store_category OWNER TO postgres;

--
-- Name: store_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_category_id_seq OWNER TO postgres;

--
-- Name: store_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_category_id_seq OWNED BY public.store_category.id;


--
-- Name: store_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_order (
    id integer NOT NULL,
    "paymentMethod" character varying(200),
    "shippingPrice" numeric(7,2),
    "totalPrice" numeric(7,2),
    "isPaid" boolean NOT NULL,
    "paidAt" timestamp with time zone,
    "isDelivered" boolean NOT NULL,
    "deliveredAt" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    user_id uuid
);


ALTER TABLE public.store_order OWNER TO postgres;

--
-- Name: store_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_order_id_seq OWNER TO postgres;

--
-- Name: store_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_order_id_seq OWNED BY public.store_order.id;


--
-- Name: store_orderitem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_orderitem (
    id integer NOT NULL,
    title character varying(200),
    qty integer,
    price numeric(7,2),
    "totalPrice" numeric(7,2),
    book_id uuid,
    order_id integer
);


ALTER TABLE public.store_orderitem OWNER TO postgres;

--
-- Name: store_orderitem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_orderitem_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_orderitem_id_seq OWNER TO postgres;

--
-- Name: store_orderitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_orderitem_id_seq OWNED BY public.store_orderitem.id;


--
-- Name: store_shippingaddress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_shippingaddress (
    id integer NOT NULL,
    address character varying(200),
    city character varying(200),
    "postalCode" character varying(200),
    country character varying(200),
    order_id integer
);


ALTER TABLE public.store_shippingaddress OWNER TO postgres;

--
-- Name: store_shippingaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_shippingaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_shippingaddress_id_seq OWNER TO postgres;

--
-- Name: store_shippingaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_shippingaddress_id_seq OWNED BY public.store_shippingaddress.id;


--
-- Name: store_subcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.store_subcategory (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(50) NOT NULL,
    parent_id bigint NOT NULL
);


ALTER TABLE public.store_subcategory OWNER TO postgres;

--
-- Name: store_subcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.store_subcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.store_subcategory_id_seq OWNER TO postgres;

--
-- Name: store_subcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.store_subcategory_id_seq OWNED BY public.store_subcategory.id;


--
-- Name: token_blacklist_blacklistedtoken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.token_blacklist_blacklistedtoken (
    id bigint NOT NULL,
    blacklisted_at timestamp with time zone NOT NULL,
    token_id bigint NOT NULL
);


ALTER TABLE public.token_blacklist_blacklistedtoken OWNER TO postgres;

--
-- Name: token_blacklist_blacklistedtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.token_blacklist_blacklistedtoken_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.token_blacklist_blacklistedtoken_id_seq OWNER TO postgres;

--
-- Name: token_blacklist_blacklistedtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.token_blacklist_blacklistedtoken_id_seq OWNED BY public.token_blacklist_blacklistedtoken.id;


--
-- Name: token_blacklist_outstandingtoken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.token_blacklist_outstandingtoken (
    id bigint NOT NULL,
    token text NOT NULL,
    created_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    user_id uuid,
    jti character varying(255) NOT NULL
);


ALTER TABLE public.token_blacklist_outstandingtoken OWNER TO postgres;

--
-- Name: token_blacklist_outstandingtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.token_blacklist_outstandingtoken_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.token_blacklist_outstandingtoken_id_seq OWNER TO postgres;

--
-- Name: token_blacklist_outstandingtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.token_blacklist_outstandingtoken_id_seq OWNED BY public.token_blacklist_outstandingtoken.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: blog_article_tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_article_tags ALTER COLUMN id SET DEFAULT nextval('public.blog_article_tags_id_seq'::regclass);


--
-- Name: blog_articlefavorite id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_articlefavorite ALTER COLUMN id SET DEFAULT nextval('public.blog_articlefavorite_id_seq'::regclass);


--
-- Name: blog_articlelike id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_articlelike ALTER COLUMN id SET DEFAULT nextval('public.blog_articlelike_id_seq'::regclass);


--
-- Name: blog_articletag id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_articletag ALTER COLUMN id SET DEFAULT nextval('public.blog_articletag_id_seq'::regclass);


--
-- Name: blog_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_category ALTER COLUMN id SET DEFAULT nextval('public.blog_category_id_seq'::regclass);


--
-- Name: blog_extradescription id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_extradescription ALTER COLUMN id SET DEFAULT nextval('public.blog_extradescription_id_seq'::regclass);


--
-- Name: blog_subcategory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_subcategory ALTER COLUMN id SET DEFAULT nextval('public.blog_subcategory_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: rest_users_customuser_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_users_customuser_groups ALTER COLUMN id SET DEFAULT nextval('public.rest_users_customuser_groups_id_seq'::regclass);


--
-- Name: rest_users_customuser_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_users_customuser_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.rest_users_customuser_user_permissions_id_seq'::regclass);


--
-- Name: store_book_tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_book_tags ALTER COLUMN id SET DEFAULT nextval('public.store_book_tags_id_seq'::regclass);


--
-- Name: store_booktag id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_booktag ALTER COLUMN id SET DEFAULT nextval('public.store_booktag_id_seq'::regclass);


--
-- Name: store_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_category ALTER COLUMN id SET DEFAULT nextval('public.store_category_id_seq'::regclass);


--
-- Name: store_order id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_order ALTER COLUMN id SET DEFAULT nextval('public.store_order_id_seq'::regclass);


--
-- Name: store_orderitem id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_orderitem ALTER COLUMN id SET DEFAULT nextval('public.store_orderitem_id_seq'::regclass);


--
-- Name: store_shippingaddress id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_shippingaddress ALTER COLUMN id SET DEFAULT nextval('public.store_shippingaddress_id_seq'::regclass);


--
-- Name: store_subcategory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_subcategory ALTER COLUMN id SET DEFAULT nextval('public.store_subcategory_id_seq'::regclass);


--
-- Name: token_blacklist_blacklistedtoken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_blacklist_blacklistedtoken ALTER COLUMN id SET DEFAULT nextval('public.token_blacklist_blacklistedtoken_id_seq'::regclass);


--
-- Name: token_blacklist_outstandingtoken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_blacklist_outstandingtoken ALTER COLUMN id SET DEFAULT nextval('public.token_blacklist_outstandingtoken_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3645.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3647.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3643.dat';

--
-- Data for Name: blog_article; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_article (id, slug, image, title, main_description, num_comments, created_at, updated_at, category_id, author_id, video, num_likes, source_link, source_name, views) FROM stdin;
\.
COPY public.blog_article (id, slug, image, title, main_description, num_comments, created_at, updated_at, category_id, author_id, video, num_likes, source_link, source_name, views) FROM '$$PATH$$/3661.dat';

--
-- Data for Name: blog_article_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_article_tags (id, article_id, articletag_id) FROM stdin;
\.
COPY public.blog_article_tags (id, article_id, articletag_id) FROM '$$PATH$$/3663.dat';

--
-- Data for Name: blog_articlefavorite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_articlefavorite (id, created_at, article_id, user_id) FROM stdin;
\.
COPY public.blog_articlefavorite (id, created_at, article_id, user_id) FROM '$$PATH$$/3690.dat';

--
-- Data for Name: blog_articlelike; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_articlelike (id, created_at, article_id, user_id) FROM stdin;
\.
COPY public.blog_articlelike (id, created_at, article_id, user_id) FROM '$$PATH$$/3688.dat';

--
-- Data for Name: blog_articletag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_articletag (id, name, slug, created_at) FROM stdin;
\.
COPY public.blog_articletag (id, name, slug, created_at) FROM '$$PATH$$/3656.dat';

--
-- Data for Name: blog_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_category (id, name, slug) FROM stdin;
\.
COPY public.blog_category (id, name, slug) FROM '$$PATH$$/3658.dat';

--
-- Data for Name: blog_comment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_comment (id, title, description, rating, created_at, updated_at, article_id, user_id, verified) FROM stdin;
\.
COPY public.blog_comment (id, title, description, rating, created_at, updated_at, article_id, user_id, verified) FROM '$$PATH$$/3684.dat';

--
-- Data for Name: blog_extradescription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_extradescription (id, image, video, main_description, article_id, title) FROM stdin;
\.
COPY public.blog_extradescription (id, image, video, main_description, article_id, title) FROM '$$PATH$$/3686.dat';

--
-- Data for Name: blog_subcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_subcategory (id, name, slug, parent_id) FROM stdin;
\.
COPY public.blog_subcategory (id, name, slug, parent_id) FROM '$$PATH$$/3660.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3654.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3641.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3639.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3664.dat';

--
-- Data for Name: rest_users_customuser; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rest_users_customuser (password, last_login, is_superuser, first_name, last_name, is_staff, is_active, date_joined, id, image, username, email, is_verify) FROM stdin;
\.
COPY public.rest_users_customuser (password, last_login, is_superuser, first_name, last_name, is_staff, is_active, date_joined, id, image, username, email, is_verify) FROM '$$PATH$$/3648.dat';

--
-- Data for Name: rest_users_customuser_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rest_users_customuser_groups (id, customuser_id, group_id) FROM stdin;
\.
COPY public.rest_users_customuser_groups (id, customuser_id, group_id) FROM '$$PATH$$/3650.dat';

--
-- Data for Name: rest_users_customuser_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rest_users_customuser_user_permissions (id, customuser_id, permission_id) FROM stdin;
\.
COPY public.rest_users_customuser_user_permissions (id, customuser_id, permission_id) FROM '$$PATH$$/3652.dat';

--
-- Data for Name: store_book; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_book (id, slug, image, title, publisher, description, rating, "numReviews", price, "countInStock", "createdAt", category_id, user_id) FROM stdin;
\.
COPY public.store_book (id, slug, image, title, publisher, description, rating, "numReviews", price, "countInStock", "createdAt", category_id, user_id) FROM '$$PATH$$/3665.dat';

--
-- Data for Name: store_book_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_book_tags (id, book_id, booktag_id) FROM stdin;
\.
COPY public.store_book_tags (id, book_id, booktag_id) FROM '$$PATH$$/3679.dat';

--
-- Data for Name: store_booktag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_booktag (id, name, slug, created_at) FROM stdin;
\.
COPY public.store_booktag (id, name, slug, created_at) FROM '$$PATH$$/3667.dat';

--
-- Data for Name: store_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_category (id, name, slug) FROM stdin;
\.
COPY public.store_category (id, name, slug) FROM '$$PATH$$/3669.dat';

--
-- Data for Name: store_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_order (id, "paymentMethod", "shippingPrice", "totalPrice", "isPaid", "paidAt", "isDelivered", "deliveredAt", "createdAt", user_id) FROM stdin;
\.
COPY public.store_order (id, "paymentMethod", "shippingPrice", "totalPrice", "isPaid", "paidAt", "isDelivered", "deliveredAt", "createdAt", user_id) FROM '$$PATH$$/3671.dat';

--
-- Data for Name: store_orderitem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_orderitem (id, title, qty, price, "totalPrice", book_id, order_id) FROM stdin;
\.
COPY public.store_orderitem (id, title, qty, price, "totalPrice", book_id, order_id) FROM '$$PATH$$/3677.dat';

--
-- Data for Name: store_shippingaddress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_shippingaddress (id, address, city, "postalCode", country, order_id) FROM stdin;
\.
COPY public.store_shippingaddress (id, address, city, "postalCode", country, order_id) FROM '$$PATH$$/3675.dat';

--
-- Data for Name: store_subcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.store_subcategory (id, name, slug, parent_id) FROM stdin;
\.
COPY public.store_subcategory (id, name, slug, parent_id) FROM '$$PATH$$/3673.dat';

--
-- Data for Name: token_blacklist_blacklistedtoken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.token_blacklist_blacklistedtoken (id, blacklisted_at, token_id) FROM stdin;
\.
COPY public.token_blacklist_blacklistedtoken (id, blacklisted_at, token_id) FROM '$$PATH$$/3680.dat';

--
-- Data for Name: token_blacklist_outstandingtoken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.token_blacklist_outstandingtoken (id, token, created_at, expires_at, user_id, jti) FROM stdin;
\.
COPY public.token_blacklist_outstandingtoken (id, token, created_at, expires_at, user_id, jti) FROM '$$PATH$$/3681.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 32, true);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 32, true);


--
-- Name: blog_article_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_article_tags_id_seq', 30, true);


--
-- Name: blog_articlefavorite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_articlefavorite_id_seq', 1, true);


--
-- Name: blog_articlelike_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_articlelike_id_seq', 14, true);


--
-- Name: blog_articletag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_articletag_id_seq', 8, true);


--
-- Name: blog_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_category_id_seq', 10, true);


--
-- Name: blog_extradescription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_extradescription_id_seq', 9, true);


--
-- Name: blog_subcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blog_subcategory_id_seq', 10, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 203, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 15, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 86, true);


--
-- Name: rest_users_customuser_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rest_users_customuser_groups_id_seq', 1, true);


--
-- Name: rest_users_customuser_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rest_users_customuser_user_permissions_id_seq', 1, false);


--
-- Name: store_book_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_book_tags_id_seq', 1, false);


--
-- Name: store_booktag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_booktag_id_seq', 1, false);


--
-- Name: store_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_category_id_seq', 1, false);


--
-- Name: store_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_order_id_seq', 1, false);


--
-- Name: store_orderitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_orderitem_id_seq', 1, false);


--
-- Name: store_shippingaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_shippingaddress_id_seq', 1, false);


--
-- Name: store_subcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.store_subcategory_id_seq', 1, false);


--
-- Name: token_blacklist_blacklistedtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.token_blacklist_blacklistedtoken_id_seq', 3, true);


--
-- Name: token_blacklist_outstandingtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.token_blacklist_outstandingtoken_id_seq', 343, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: blog_article blog_article_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_article
    ADD CONSTRAINT blog_article_pkey PRIMARY KEY (id);


--
-- Name: blog_article blog_article_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_article
    ADD CONSTRAINT blog_article_slug_key UNIQUE (slug);


--
-- Name: blog_article_tags blog_article_tags_article_id_articletag_id_8b828744_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_article_tags
    ADD CONSTRAINT blog_article_tags_article_id_articletag_id_8b828744_uniq UNIQUE (article_id, articletag_id);


--
-- Name: blog_article_tags blog_article_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_article_tags
    ADD CONSTRAINT blog_article_tags_pkey PRIMARY KEY (id);


--
-- Name: blog_articlefavorite blog_articlefavorite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_articlefavorite
    ADD CONSTRAINT blog_articlefavorite_pkey PRIMARY KEY (id);


--
-- Name: blog_articlelike blog_articlelike_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_articlelike
    ADD CONSTRAINT blog_articlelike_pkey PRIMARY KEY (id);


--
-- Name: blog_articletag blog_articletag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_articletag
    ADD CONSTRAINT blog_articletag_pkey PRIMARY KEY (id);


--
-- Name: blog_articletag blog_articletag_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_articletag
    ADD CONSTRAINT blog_articletag_slug_key UNIQUE (slug);


--
-- Name: blog_category blog_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_category
    ADD CONSTRAINT blog_category_pkey PRIMARY KEY (id);


--
-- Name: blog_category blog_category_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_category
    ADD CONSTRAINT blog_category_slug_key UNIQUE (slug);


--
-- Name: blog_comment blog_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_comment
    ADD CONSTRAINT blog_comment_pkey PRIMARY KEY (id);


--
-- Name: blog_extradescription blog_extradescription_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_extradescription
    ADD CONSTRAINT blog_extradescription_pkey PRIMARY KEY (id);


--
-- Name: blog_subcategory blog_subcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_subcategory
    ADD CONSTRAINT blog_subcategory_pkey PRIMARY KEY (id);


--
-- Name: blog_subcategory blog_subcategory_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_subcategory
    ADD CONSTRAINT blog_subcategory_slug_key UNIQUE (slug);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: rest_users_customuser rest_users_customuser_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_users_customuser
    ADD CONSTRAINT rest_users_customuser_email_key UNIQUE (email);


--
-- Name: rest_users_customuser_groups rest_users_customuser_gr_customuser_id_group_id_c2012ab8_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_users_customuser_groups
    ADD CONSTRAINT rest_users_customuser_gr_customuser_id_group_id_c2012ab8_uniq UNIQUE (customuser_id, group_id);


--
-- Name: rest_users_customuser_groups rest_users_customuser_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_users_customuser_groups
    ADD CONSTRAINT rest_users_customuser_groups_pkey PRIMARY KEY (id);


--
-- Name: rest_users_customuser rest_users_customuser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_users_customuser
    ADD CONSTRAINT rest_users_customuser_pkey PRIMARY KEY (id);


--
-- Name: rest_users_customuser_user_permissions rest_users_customuser_us_customuser_id_permission_d01ba1b4_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_users_customuser_user_permissions
    ADD CONSTRAINT rest_users_customuser_us_customuser_id_permission_d01ba1b4_uniq UNIQUE (customuser_id, permission_id);


--
-- Name: rest_users_customuser_user_permissions rest_users_customuser_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_users_customuser_user_permissions
    ADD CONSTRAINT rest_users_customuser_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: rest_users_customuser rest_users_customuser_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_users_customuser
    ADD CONSTRAINT rest_users_customuser_username_key UNIQUE (username);


--
-- Name: store_book store_book_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_book
    ADD CONSTRAINT store_book_pkey PRIMARY KEY (id);


--
-- Name: store_book store_book_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_book
    ADD CONSTRAINT store_book_slug_key UNIQUE (slug);


--
-- Name: store_book_tags store_book_tags_book_id_booktag_id_d2bd4cfc_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_book_tags
    ADD CONSTRAINT store_book_tags_book_id_booktag_id_d2bd4cfc_uniq UNIQUE (book_id, booktag_id);


--
-- Name: store_book_tags store_book_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_book_tags
    ADD CONSTRAINT store_book_tags_pkey PRIMARY KEY (id);


--
-- Name: store_booktag store_booktag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_booktag
    ADD CONSTRAINT store_booktag_pkey PRIMARY KEY (id);


--
-- Name: store_category store_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_category
    ADD CONSTRAINT store_category_pkey PRIMARY KEY (id);


--
-- Name: store_category store_category_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_category
    ADD CONSTRAINT store_category_slug_key UNIQUE (slug);


--
-- Name: store_order store_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_order
    ADD CONSTRAINT store_order_pkey PRIMARY KEY (id);


--
-- Name: store_orderitem store_orderitem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_orderitem
    ADD CONSTRAINT store_orderitem_pkey PRIMARY KEY (id);


--
-- Name: store_shippingaddress store_shippingaddress_order_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_shippingaddress
    ADD CONSTRAINT store_shippingaddress_order_id_key UNIQUE (order_id);


--
-- Name: store_shippingaddress store_shippingaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_shippingaddress
    ADD CONSTRAINT store_shippingaddress_pkey PRIMARY KEY (id);


--
-- Name: store_subcategory store_subcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_subcategory
    ADD CONSTRAINT store_subcategory_pkey PRIMARY KEY (id);


--
-- Name: store_subcategory store_subcategory_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_subcategory
    ADD CONSTRAINT store_subcategory_slug_key UNIQUE (slug);


--
-- Name: token_blacklist_blacklistedtoken token_blacklist_blacklistedtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_blacklist_blacklistedtoken
    ADD CONSTRAINT token_blacklist_blacklistedtoken_pkey PRIMARY KEY (id);


--
-- Name: token_blacklist_blacklistedtoken token_blacklist_blacklistedtoken_token_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_blacklist_blacklistedtoken
    ADD CONSTRAINT token_blacklist_blacklistedtoken_token_id_key UNIQUE (token_id);


--
-- Name: token_blacklist_outstandingtoken token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_blacklist_outstandingtoken
    ADD CONSTRAINT token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_uniq UNIQUE (jti);


--
-- Name: token_blacklist_outstandingtoken token_blacklist_outstandingtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_blacklist_outstandingtoken
    ADD CONSTRAINT token_blacklist_outstandingtoken_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: blog_article_author_id_905add38; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_article_author_id_905add38 ON public.blog_article USING btree (author_id);


--
-- Name: blog_article_category_id_7e38f15e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_article_category_id_7e38f15e ON public.blog_article USING btree (category_id);


--
-- Name: blog_article_slug_c3fca16d_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_article_slug_c3fca16d_like ON public.blog_article USING btree (slug varchar_pattern_ops);


--
-- Name: blog_article_tags_article_id_82c02dd6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_article_tags_article_id_82c02dd6 ON public.blog_article_tags USING btree (article_id);


--
-- Name: blog_article_tags_articletag_id_ec157d3f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_article_tags_articletag_id_ec157d3f ON public.blog_article_tags USING btree (articletag_id);


--
-- Name: blog_articlefavorite_article_id_f465ea5b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_articlefavorite_article_id_f465ea5b ON public.blog_articlefavorite USING btree (article_id);


--
-- Name: blog_articlefavorite_user_id_26e0be4c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_articlefavorite_user_id_26e0be4c ON public.blog_articlefavorite USING btree (user_id);


--
-- Name: blog_articlelike_article_id_65698d50; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_articlelike_article_id_65698d50 ON public.blog_articlelike USING btree (article_id);


--
-- Name: blog_articlelike_user_id_af7546cb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_articlelike_user_id_af7546cb ON public.blog_articlelike USING btree (user_id);


--
-- Name: blog_articletag_slug_526bf927_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_articletag_slug_526bf927_like ON public.blog_articletag USING btree (slug varchar_pattern_ops);


--
-- Name: blog_category_slug_92643dc5_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_category_slug_92643dc5_like ON public.blog_category USING btree (slug varchar_pattern_ops);


--
-- Name: blog_comment_article_id_3d58bca6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_comment_article_id_3d58bca6 ON public.blog_comment USING btree (article_id);


--
-- Name: blog_comment_user_id_59a54155; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_comment_user_id_59a54155 ON public.blog_comment USING btree (user_id);


--
-- Name: blog_extradescription_article_id_a11189cc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_extradescription_article_id_a11189cc ON public.blog_extradescription USING btree (article_id);


--
-- Name: blog_subcategory_parent_id_bcc39d9a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_subcategory_parent_id_bcc39d9a ON public.blog_subcategory USING btree (parent_id);


--
-- Name: blog_subcategory_slug_7605af0a_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_subcategory_slug_7605af0a_like ON public.blog_subcategory USING btree (slug varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: rest_users_customuser_email_598f7587_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rest_users_customuser_email_598f7587_like ON public.rest_users_customuser USING btree (email varchar_pattern_ops);


--
-- Name: rest_users_customuser_groups_customuser_id_0ef3434a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rest_users_customuser_groups_customuser_id_0ef3434a ON public.rest_users_customuser_groups USING btree (customuser_id);


--
-- Name: rest_users_customuser_groups_group_id_b70ca8c3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rest_users_customuser_groups_group_id_b70ca8c3 ON public.rest_users_customuser_groups USING btree (group_id);


--
-- Name: rest_users_customuser_user_permissions_customuser_id_3f70b7cf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rest_users_customuser_user_permissions_customuser_id_3f70b7cf ON public.rest_users_customuser_user_permissions USING btree (customuser_id);


--
-- Name: rest_users_customuser_user_permissions_permission_id_ae6e387b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rest_users_customuser_user_permissions_permission_id_ae6e387b ON public.rest_users_customuser_user_permissions USING btree (permission_id);


--
-- Name: rest_users_customuser_username_6de8014d_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rest_users_customuser_username_6de8014d_like ON public.rest_users_customuser USING btree (username varchar_pattern_ops);


--
-- Name: store_book_category_id_46de4d82; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX store_book_category_id_46de4d82 ON public.store_book USING btree (category_id);


--
-- Name: store_book_slug_e5087f7b_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX store_book_slug_e5087f7b_like ON public.store_book USING btree (slug varchar_pattern_ops);


--
-- Name: store_book_tags_book_id_bd2c0559; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX store_book_tags_book_id_bd2c0559 ON public.store_book_tags USING btree (book_id);


--
-- Name: store_book_tags_booktag_id_7e0c71bf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX store_book_tags_booktag_id_7e0c71bf ON public.store_book_tags USING btree (booktag_id);


--
-- Name: store_book_user_id_ab31a05f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX store_book_user_id_ab31a05f ON public.store_book USING btree (user_id);


--
-- Name: store_category_slug_2d349264_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX store_category_slug_2d349264_like ON public.store_category USING btree (slug varchar_pattern_ops);


--
-- Name: store_order_user_id_ae5f7a5f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX store_order_user_id_ae5f7a5f ON public.store_order USING btree (user_id);


--
-- Name: store_orderitem_book_id_290bb879; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX store_orderitem_book_id_290bb879 ON public.store_orderitem USING btree (book_id);


--
-- Name: store_orderitem_order_id_acf8722d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX store_orderitem_order_id_acf8722d ON public.store_orderitem USING btree (order_id);


--
-- Name: store_subcategory_parent_id_8332a1e9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX store_subcategory_parent_id_8332a1e9 ON public.store_subcategory USING btree (parent_id);


--
-- Name: store_subcategory_slug_c7e435fe_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX store_subcategory_slug_c7e435fe_like ON public.store_subcategory USING btree (slug varchar_pattern_ops);


--
-- Name: token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_like ON public.token_blacklist_outstandingtoken USING btree (jti varchar_pattern_ops);


--
-- Name: token_blacklist_outstandingtoken_user_id_83bc629a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX token_blacklist_outstandingtoken_user_id_83bc629a ON public.token_blacklist_outstandingtoken USING btree (user_id);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_article blog_article_author_id_905add38_fk_rest_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_article
    ADD CONSTRAINT blog_article_author_id_905add38_fk_rest_users_customuser_id FOREIGN KEY (author_id) REFERENCES public.rest_users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_article blog_article_category_id_7e38f15e_fk_blog_subcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_article
    ADD CONSTRAINT blog_article_category_id_7e38f15e_fk_blog_subcategory_id FOREIGN KEY (category_id) REFERENCES public.blog_subcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_article_tags blog_article_tags_article_id_82c02dd6_fk_blog_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_article_tags
    ADD CONSTRAINT blog_article_tags_article_id_82c02dd6_fk_blog_article_id FOREIGN KEY (article_id) REFERENCES public.blog_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_article_tags blog_article_tags_articletag_id_ec157d3f_fk_blog_articletag_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_article_tags
    ADD CONSTRAINT blog_article_tags_articletag_id_ec157d3f_fk_blog_articletag_id FOREIGN KEY (articletag_id) REFERENCES public.blog_articletag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_articlefavorite blog_articlefavorite_article_id_f465ea5b_fk_blog_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_articlefavorite
    ADD CONSTRAINT blog_articlefavorite_article_id_f465ea5b_fk_blog_article_id FOREIGN KEY (article_id) REFERENCES public.blog_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_articlefavorite blog_articlefavorite_user_id_26e0be4c_fk_rest_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_articlefavorite
    ADD CONSTRAINT blog_articlefavorite_user_id_26e0be4c_fk_rest_user FOREIGN KEY (user_id) REFERENCES public.rest_users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_articlelike blog_articlelike_article_id_65698d50_fk_blog_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_articlelike
    ADD CONSTRAINT blog_articlelike_article_id_65698d50_fk_blog_article_id FOREIGN KEY (article_id) REFERENCES public.blog_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_articlelike blog_articlelike_user_id_af7546cb_fk_rest_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_articlelike
    ADD CONSTRAINT blog_articlelike_user_id_af7546cb_fk_rest_users_customuser_id FOREIGN KEY (user_id) REFERENCES public.rest_users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_comment blog_comment_article_id_3d58bca6_fk_blog_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_comment
    ADD CONSTRAINT blog_comment_article_id_3d58bca6_fk_blog_article_id FOREIGN KEY (article_id) REFERENCES public.blog_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_comment blog_comment_user_id_59a54155_fk_rest_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_comment
    ADD CONSTRAINT blog_comment_user_id_59a54155_fk_rest_users_customuser_id FOREIGN KEY (user_id) REFERENCES public.rest_users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_extradescription blog_extradescription_article_id_a11189cc_fk_blog_article_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_extradescription
    ADD CONSTRAINT blog_extradescription_article_id_a11189cc_fk_blog_article_id FOREIGN KEY (article_id) REFERENCES public.blog_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_subcategory blog_subcategory_parent_id_bcc39d9a_fk_blog_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_subcategory
    ADD CONSTRAINT blog_subcategory_parent_id_bcc39d9a_fk_blog_category_id FOREIGN KEY (parent_id) REFERENCES public.blog_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_rest_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_rest_users_customuser_id FOREIGN KEY (user_id) REFERENCES public.rest_users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rest_users_customuser_groups rest_users_customuse_customuser_id_0ef3434a_fk_rest_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_users_customuser_groups
    ADD CONSTRAINT rest_users_customuse_customuser_id_0ef3434a_fk_rest_user FOREIGN KEY (customuser_id) REFERENCES public.rest_users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rest_users_customuser_user_permissions rest_users_customuse_customuser_id_3f70b7cf_fk_rest_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_users_customuser_user_permissions
    ADD CONSTRAINT rest_users_customuse_customuser_id_3f70b7cf_fk_rest_user FOREIGN KEY (customuser_id) REFERENCES public.rest_users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rest_users_customuser_user_permissions rest_users_customuse_permission_id_ae6e387b_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_users_customuser_user_permissions
    ADD CONSTRAINT rest_users_customuse_permission_id_ae6e387b_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rest_users_customuser_groups rest_users_customuser_groups_group_id_b70ca8c3_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_users_customuser_groups
    ADD CONSTRAINT rest_users_customuser_groups_group_id_b70ca8c3_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: store_book store_book_category_id_46de4d82_fk_store_subcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_book
    ADD CONSTRAINT store_book_category_id_46de4d82_fk_store_subcategory_id FOREIGN KEY (category_id) REFERENCES public.store_subcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: store_book_tags store_book_tags_book_id_bd2c0559_fk_store_book_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_book_tags
    ADD CONSTRAINT store_book_tags_book_id_bd2c0559_fk_store_book_id FOREIGN KEY (book_id) REFERENCES public.store_book(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: store_book_tags store_book_tags_booktag_id_7e0c71bf_fk_store_booktag_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_book_tags
    ADD CONSTRAINT store_book_tags_booktag_id_7e0c71bf_fk_store_booktag_id FOREIGN KEY (booktag_id) REFERENCES public.store_booktag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: store_book store_book_user_id_ab31a05f_fk_rest_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_book
    ADD CONSTRAINT store_book_user_id_ab31a05f_fk_rest_users_customuser_id FOREIGN KEY (user_id) REFERENCES public.rest_users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: store_order store_order_user_id_ae5f7a5f_fk_rest_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_order
    ADD CONSTRAINT store_order_user_id_ae5f7a5f_fk_rest_users_customuser_id FOREIGN KEY (user_id) REFERENCES public.rest_users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: store_orderitem store_orderitem_book_id_290bb879_fk_store_book_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_orderitem
    ADD CONSTRAINT store_orderitem_book_id_290bb879_fk_store_book_id FOREIGN KEY (book_id) REFERENCES public.store_book(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: store_orderitem store_orderitem_order_id_acf8722d_fk_store_order_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_orderitem
    ADD CONSTRAINT store_orderitem_order_id_acf8722d_fk_store_order_id FOREIGN KEY (order_id) REFERENCES public.store_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: store_shippingaddress store_shippingaddress_order_id_e6decfbb_fk_store_order_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_shippingaddress
    ADD CONSTRAINT store_shippingaddress_order_id_e6decfbb_fk_store_order_id FOREIGN KEY (order_id) REFERENCES public.store_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: store_subcategory store_subcategory_parent_id_8332a1e9_fk_store_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.store_subcategory
    ADD CONSTRAINT store_subcategory_parent_id_8332a1e9_fk_store_category_id FOREIGN KEY (parent_id) REFERENCES public.store_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: token_blacklist_blacklistedtoken token_blacklist_blacklistedtoken_token_id_3cc7fe56_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_blacklist_blacklistedtoken
    ADD CONSTRAINT token_blacklist_blacklistedtoken_token_id_3cc7fe56_fk FOREIGN KEY (token_id) REFERENCES public.token_blacklist_outstandingtoken(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: token_blacklist_outstandingtoken token_blacklist_outs_user_id_83bc629a_fk_rest_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_blacklist_outstandingtoken
    ADD CONSTRAINT token_blacklist_outs_user_id_83bc629a_fk_rest_user FOREIGN KEY (user_id) REFERENCES public.rest_users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

